<footer class="w3-container w3-blue-grey">
  <p class="w3-opacity">Smart health Prediction</p>
</footer>