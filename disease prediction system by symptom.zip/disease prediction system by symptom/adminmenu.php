<title>Smart Health Prediction Using Data Mining</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<link rel="stylesheet" href="https://www.w3schools.com/lib/w3-theme-teal.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.3.0/css/font-awesome.min.css">

<div class="w3-bar w3-theme">
  <a href="adddoctor.php" class="w3-bar-item w3-button w3-padding-16">Add Doctor</a>
  <a href="adddisease.php" class="w3-bar-item w3-button w3-padding-16">Add Disease</a>
  <a href="viewp.php" class="w3-bar-item w3-button w3-padding-16">View Patient</a>
  <a href="viewdoc.php" class="w3-bar-item w3-button w3-padding-16">View Doctor</a>
  <a href="viewdis.php" class="w3-bar-item w3-button w3-padding-16">View Diseases</a>
  <a href="viewfeed.php" class="w3-bar-item w3-button w3-padding-16">View Feedback</a>
  <a href="Logout.php" class="w3-bar-item w3-button w3-padding-16">Logout</a>
</div>