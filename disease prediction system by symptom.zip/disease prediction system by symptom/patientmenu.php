<title>Smart Health Prediction Using Data Mining</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<link rel="stylesheet" href="https://www.w3schools.com/lib/w3-theme-teal.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.3.0/css/font-awesome.min.css">

<div class="w3-bar w3-theme">
  <a href="myprofile.php" class="w3-bar-item w3-button w3-padding-16">My Profile</a>
  <a href="searchdi.php" class="w3-bar-item w3-button w3-padding-16">Search Disease</a>
  <a href="searchdoc.php" class="w3-bar-item w3-button w3-padding-16">Search Doctor</a>
  <a href="feedback.php" class="w3-bar-item w3-button w3-padding-16">Feedback</a>
  <a href="Logout.php" class="w3-bar-item w3-button w3-padding-16">Logout</a>

</div>